import SwiftUI

@main
struct SenikMarketingApp: App {
    @StateObject private var serverSettings = ServerSettingsStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(serverSettings)
        }
    }
}

private struct RootView: View {
    @EnvironmentObject private var serverSettings: ServerSettingsStore

    var body: some View {
        NavigationStack {
            if serverSettings.isConfigured {
                LoginView()
            } else {
                ServerSettingsView()
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
    }
}
