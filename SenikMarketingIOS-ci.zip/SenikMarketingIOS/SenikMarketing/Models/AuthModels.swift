import Foundation

struct LoginRequestModel: Codable {
    var userName: String
    var password: String
    var deviceName: String
    var macAddress: String
}

struct ValidationModel: Codable {
    var isValid: Bool?
    var message: String?
}

struct UserModel: Codable {
    var id: Int64?
    var userName: String?
    var fullName: String?
}

struct LoginResponseModel: Codable {
    var message: String?
    var success: Bool?
    var token: String?
    var validation: ValidationModel?
    var user: UserModel?
}
