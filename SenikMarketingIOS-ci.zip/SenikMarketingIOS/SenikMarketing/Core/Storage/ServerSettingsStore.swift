import Foundation

@MainActor
final class ServerSettingsStore: ObservableObject {
    @Published private(set) var host: String
    @Published private(set) var port: String
    @Published private(set) var hasSavedConfiguration: Bool

    private let defaults: UserDefaults
    private let hostKey = "server.host"
    private let portKey = "server.port"
    private let configuredKey = "server.configured"

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        self.host = defaults.string(forKey: hostKey) ?? ""
        self.port = defaults.string(forKey: portKey) ?? ""
        self.hasSavedConfiguration = defaults.bool(forKey: configuredKey)
    }

    var isConfigured: Bool {
        hasSavedConfiguration && !host.isEmpty && Int(port) != nil
    }

    var baseURL: URL? {
        guard isConfigured else { return nil }
        return URL(string: "http://\(host):\(port)")
    }

    func save(host: String, port: String) {
        let cleanHost = host.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanPort = port.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanHost.isEmpty, Int(cleanPort) != nil else { return }

        self.host = cleanHost
        self.port = cleanPort
        self.hasSavedConfiguration = true
        defaults.set(cleanHost, forKey: hostKey)
        defaults.set(cleanPort, forKey: portKey)
        defaults.set(true, forKey: configuredKey)
    }

    func clear() {
        host = ""
        port = ""
        hasSavedConfiguration = false
        defaults.removeObject(forKey: hostKey)
        defaults.removeObject(forKey: portKey)
        defaults.set(false, forKey: configuredKey)
    }
}
