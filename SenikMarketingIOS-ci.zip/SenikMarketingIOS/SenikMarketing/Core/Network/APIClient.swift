import Foundation

struct APIClient {
    let baseURL: URL
    var session: URLSession = .shared

    func request<Response: Decodable, Body: Encodable>(
        _ path: String,
        method: String = "POST",
        body: Body,
        response: Response.Type = Response.self
    ) async throws -> Response {
        let url = baseURL.appendingPathComponent(path.trimmingCharacters(in: CharacterSet(charactersIn: "/")))
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(body)
        let (data, urlResponse) = try await session.data(for: request)
        guard let http = urlResponse as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }
        return try JSONDecoder().decode(Response.self, from: data)
    }

    func testConnection() async throws {
        var request = URLRequest(url: baseURL)
        request.timeoutInterval = 5
        _ = try await session.data(for: request)
    }
}
