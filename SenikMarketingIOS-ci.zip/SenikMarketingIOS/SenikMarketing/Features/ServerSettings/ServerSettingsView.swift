import SwiftUI

struct ServerSettingsView: View {
    @EnvironmentObject private var settings: ServerSettingsStore
    @State private var host = ""
    @State private var port = ""
    @State private var statusText = ""
    @State private var isTesting = false
    @State private var connectionSucceeded = false

    private var validInput: Bool {
        !host.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && Int(port) != nil
    }

    var body: some View {
        Form {
            Section("تنظیمات سرور") {
                TextField("IP سرور", text: $host)
                    .textInputAutocapitalization(.never)
                    .keyboardType(.numbersAndPunctuation)
                    .multilineTextAlignment(.left)
                    .onChange(of: host) { _ in connectionSucceeded = false }

                TextField("Port", text: $port)
                    .keyboardType(.numberPad)
                    .multilineTextAlignment(.left)
                    .onChange(of: port) { _ in connectionSucceeded = false }
            }

            Section {
                Button(isTesting ? "در حال بررسی..." : "تست اتصال") {
                    Task { await testConnection() }
                }
                .disabled(!validInput || isTesting)

                Button("ذخیره و ادامه") {
                    settings.save(host: host, port: port)
                }
                .disabled(!connectionSucceeded)

                if !statusText.isEmpty {
                    Text(statusText)
                }
            }
        }
        .navigationTitle("اتصال به سرور")
        .onAppear {
            host = settings.host
            port = settings.port
        }
    }

    @MainActor
    private func testConnection() async {
        let cleanHost = host.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanPort = port.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: "http://\(cleanHost):\(cleanPort)") else {
            statusText = "IP و Port معتبر وارد کنید."
            return
        }

        isTesting = true
        connectionSucceeded = false
        defer { isTesting = false }

        do {
            try await APIClient(baseURL: url).testConnection()
            connectionSucceeded = true
            statusText = "اتصال با سرور برقرار شد."
        } catch {
            statusText = "ارتباط با سرور برقرار نشد."
        }
    }
}
