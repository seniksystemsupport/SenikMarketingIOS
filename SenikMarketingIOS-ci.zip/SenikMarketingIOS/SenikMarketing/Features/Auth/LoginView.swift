import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

struct LoginView: View {
    @EnvironmentObject private var settings: ServerSettingsStore
    @State private var userName = ""
    @State private var password = ""
    @State private var message = ""
    @State private var isLoading = false

    var body: some View {
        Form {
            Section("ورود") {
                TextField("نام کاربری", text: $userName)
                    .textInputAutocapitalization(.never)
                SecureField("رمز عبور", text: $password)
                Button(isLoading ? "در حال ورود..." : "ورود") {
                    Task { await login() }
                }
                .disabled(userName.isEmpty || password.isEmpty || isLoading)
            }

            if !message.isEmpty {
                Section { Text(message) }
            }

            Section {
                Button("تغییر IP / Port") { settings.clear() }
            }
        }
        .navigationTitle("سه‌نیک")
    }

    @MainActor
    private func login() async {
        guard let baseURL = settings.baseURL else { return }
        isLoading = true
        defer { isLoading = false }
        let request = LoginRequestModel(
            userName: userName,
            password: password,
            deviceName: deviceName,
            macAddress: ""
        )
        do {
            let response: LoginResponseModel = try await APIClient(baseURL: baseURL)
                .request("marketing/authentication/Login", body: request)
            message = response.message ?? (response.success == true ? "ورود موفق" : "ورود ناموفق")
        } catch {
            message = "خطا در ارتباط با سرور"
        }
    }

    private var deviceName: String {
        #if canImport(UIKit)
        return UIDevice.current.name
        #else
        return "iPhone"
        #endif
    }
}
