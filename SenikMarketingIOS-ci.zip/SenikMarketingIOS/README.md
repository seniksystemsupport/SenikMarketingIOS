# Senik Marketing iOS reconstruction

Initial native SwiftUI scaffold reconstructed from marketing-release-V2.3.apk.

Current implemented scaffold:
- Dynamic per-customer server IP and port, blank by default
- Persisted local server settings
- Connection test
- RTL SwiftUI root flow
- Initial login request/response models
- Initial API client

Next reconstruction targets from APK:
- exact authentication endpoint/contract verification
- branches and app settings
- customers and account turnover
- products/groups/prices/stores
- invoices / sales / return / proforma / reserve
- factor agents / settlement agents
- offline database and sync behavior
