# نصب نسخه اولیه سه‌نیک روی iPhone

این بسته یک پروژه Native iOS با SwiftUI است. برای نصب روی iPhone باید آن را با Xcode روی macOS امضا و اجرا کنید.

## مراحل
1. Xcode را روی Mac نصب کنید.
2. پوشه را Extract کنید و `SenikMarketing.xcodeproj` را باز کنید.
3. در Xcode از مسیر **Xcode > Settings > Apple Accounts** با Apple ID وارد شوید.
4. در Project Navigator پروژه `SenikMarketing` را انتخاب کنید، سپس Target `SenikMarketing` > **Signing & Capabilities**.
5. گزینه **Automatically manage signing** روشن باشد و Team خودتان را انتخاب کنید.
6. اگر Bundle Identifier تکراری بود، `com.senik.marketing.ios` را به یک شناسه یکتا مثل `com.senik.marketing.ios.test1` تغییر دهید.
7. iPhone را با کابل به Mac وصل و Trust را تأیید کنید. در صورت درخواست، Developer Mode آیفون را فعال کنید.
8. از بالای Xcode، iPhone را به‌عنوان Run Destination انتخاب کنید و دکمه ▶ Run را بزنید.
9. بعد از نصب، داخل برنامه IP سرور و Port مشتری را وارد کنید، Test Connection را بزنید و سپس Save & Continue را انتخاب کنید.

## وضعیت این نسخه
این نسخه اولیه فقط اسکلت قابل اجرای تنظیم سرور + Login است و نسخه کامل اپ اندروید نیست. Endpoint و قرارداد Login هنوز باید روی سرور واقعی سه‌نیک تست و نهایی شود.
